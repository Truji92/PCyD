package filosofos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author alejandro
 */
public class InicializacionInvalida extends Exception {

    public InicializacionInvalida(String message) {
        super(message);
    }
    
    
}
