/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica9;

/**
 *
 * @author alejandro
 */
public class Funcion {
    
    public static double fun (double x) {
       
        return Math.sin(x*2*3.14);
    }
}
